
import { createPrivateKey, sign } from 'node:crypto';
import {
  SecretsManagerClient,
  GetSecretValueCommand
} from '@aws-sdk/client-secrets-manager';

const secrets = new SecretsManagerClient({});

const base64url = value =>
  Buffer.from(value).toString('base64url');

export const handler = async () => {
  try {
    const secretResult = await secrets.send(
      new GetSecretValueCommand({
        SecretId: process.env.APPLE_SECRET_ID
      })
    );

    const credentials = JSON.parse(secretResult.SecretString);

    const { issuerId, keyId, privateKey } = credentials;
    const bundleId = process.env.APPLE_BUNDLE_ID;

    if (!issuerId || !keyId || !privateKey || !bundleId) {
      throw new Error('Missing Apple API credentials or bundle ID');
    }

    const now = Math.floor(Date.now() / 1000);

    const header = base64url(JSON.stringify({
      alg: 'ES256',
      kid: keyId,
      typ: 'JWT'
    }));

    const payload = base64url(JSON.stringify({
      iss: issuerId,
      iat: now,
      exp: now + 300,
      aud: 'appstoreconnect-v1',
      bid: bundleId
    }));

    const signingInput = `${header}.${payload}`;

    const normalizedKey = privateKey.trim();

const keyObject = normalizedKey.includes('-----BEGIN')
  ? createPrivateKey(normalizedKey.replace(/\\n/g, '\n'))
  : createPrivateKey({
      key: Buffer.from(normalizedKey, 'base64'),
      format: 'der',
      type: 'pkcs8'
    });

const signature = sign(
  'sha256',
  Buffer.from(signingInput),
  {
    key: keyObject,
    dsaEncoding: 'ieee-p1363'
  }
).toString('base64url');

    const token = `${signingInput}.${signature}`;

    const result = await fetch(
      'https://api.storekit-sandbox.itunes.apple.com/inApps/v1/notifications/test',
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: '{}'
      }
    );

    const responseBody = await result.text();

    console.log('Apple test notification response', {
      status: result.status,
      body: responseBody
    });

    return {
      statusCode: result.status,
      body: responseBody
    };

  } catch (error) {
    console.error('Apple test request failed', {
      name: error.name,
      message: error.message
    });

    return {
      statusCode: 500,
      body: JSON.stringify({
        ok: false,
        error: error.message
      })
    };
  }
};
